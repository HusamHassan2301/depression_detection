from src.experiments.experiment_05 import run_experiment_05_comprehensive

if __name__ == "__main__":
    run_experiment_05_comprehensive()
