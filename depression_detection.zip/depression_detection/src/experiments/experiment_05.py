def run_experiment_05_comprehensive():
    print('Experiment 05 running')
